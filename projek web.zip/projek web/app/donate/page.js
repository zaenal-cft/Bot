export default function Donate() {
  return (
        <h1> HALLO </h1>
  )
}