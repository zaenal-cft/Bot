import "./globals.css"

export const metadata = {
  title: "zaenal?—",
  description: "Welcome To Bio Link zaenalz/zaaa, Find Out Info About hHim, And Stalk Him!",
  author: "zaenal",
  keywords: "zaenaly, z, zaenall, kurumi api, mbuhsapa78",
    robots: {
    index: true,
    follow: true,
  },
}

export default function Layout({ children }) {
  return (
    <html lang="id">
      <body className="bg-black grid-bg text-white min-h-screen font-sans transition-colors duration-300">
        {children}
      </body>
    </html>
  )
}