export default function GET(req, res) {
  res.status(200).json("OK!")
}